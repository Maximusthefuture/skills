---
description: Design a Spring Boot backend component (REST endpoint, Kafka/Rabbit consumer, @Scheduled or batch job, admin task, outbound integration) using the senior 6-step workflow before writing any code. Produces changesets, entity mapping, transaction boundaries, error codes and metrics.
argument-hint: Brief description of the component you want to design
disable-model-invocation: false
---

# Backend Design

You are about to help the user design a backend component. Before any code, you run the 6-step workflow from the `think-before-coding` skill, adapted to the actual context.

Initial request: $ARGUMENTS

## Step 1: Establish context

The first thing you do is ask the user one question (or infer from the request, if obvious) to classify the component:

- HTTP endpoint (`@RestController`, GraphQL `@QueryMapping`, gRPC)
- Message consumer (`@KafkaListener`, `@RabbitListener`, `@SqsListener`, webhook receiver)
- Scheduled job (`@Scheduled` + ShedLock, db-scheduler, Quartz)
- Batch / ETL (Spring Batch, chunked job, CSV import)
- Admin task / one-shot data fix (`ApplicationRunner` behind a profile, CLI module)
- Outbound integration (`RestClient`, `WebClient`, Feign, provider SDK)
- Outbox publisher / long-running worker

The skeleton of the design depends on this. A REST endpoint and a `@KafkaListener` share principles but differ in everything else: latency model, failure model (ProblemDetail vs DLT), scaling model (threads + Hikari vs partitions). Do not assume "endpoint".

If the request is unambiguous, state your classification in one sentence and move on.

## Step 2: Run the 6 steps

Invoke the `think-before-coding` skill and walk through:

1. Identify the context (just confirmed).
2. Model the data (entities, invariants as changeset constraints, JPA mapping, lifecycle).
3. List the failure modes (specific to the context).
4. Map authorization (principal, scope, enforcement point).
5. Decide transactions, idempotence and concurrency (boundary, replay, concurrent, out-of-order, outbox).
6. Decide observability (JSON logs with traceId, Micrometer meters, health groups, trace propagation).

For each step, present the answer in a few lines, then ask one targeted question if you need a decision from the user. Do not ask "what do you want for error handling?" Ask "is the caller a UI that retries on its own, or a background job that we control?"

## Step 3: Hand off to the architect

Once the six answers exist, delegate the blueprint to the `component-architect` agent. Pass the six answers as context. The agent returns the full design document.

Then ask the user to review the design. Do not start coding until they approve.

## Hard rules

- **Do not write code in this command.** This command produces a design. Implementation is a separate step.
- **Do not skip a step.** Even for "simple" components. The shorter the component, the shorter the answers, but every step gets an answer.
- **Do not propose a CRUD shape by default.** Many components are workflows, commands, or RPCs. Name the operation by what it does.
- **Adapt the questions to the context.** An admin task does not need RED metrics. A `@Scheduled` job needs a last-success gauge, not a readiness check.

## After approval

Once the user approves the design, the next step is implementation. The implementation should follow the build sequence in the blueprint and should call out which sibling skills apply:

- Schema changes -> [[data-modeling-discipline]], [[migration-safety]] (Liquibase changesets first)
- Entities, repositories, `@Transactional` -> [[jpa-and-transactions]]
- Queries -> [[query-discipline]]
- Mutations / side effects -> [[idempotency-and-side-effects]]
- Error path -> [[error-handling-as-design]]
- Instrumentation -> [[observability-by-default]]
- Tests -> [[testing-with-discernment]] (Testcontainers Postgres, not H2)

Suggest the user open a separate session for implementation, or proceed in this one if scope is small.
