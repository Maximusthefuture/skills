# Команды Maven и Gradle

**Открывай, когда:** нужна команда для одного теста, класса, интеграционного теста или модуля в multi-module.

Определи сборку по корню проекта и используй wrapper (`./mvnw`, `./gradlew`), а не глобальную установку. Если в `CLAUDE.md`/`CONTRIBUTING.md`/`README` описаны свои команды — используй их.

| Что | Maven | Gradle |
|---|---|---|
| Один тест-метод | `./mvnw -q test -Dtest='FooServiceTest#rejectsX' -Dsurefire.failIfNoSpecifiedTests=false` | `./gradlew test --tests 'com.example.FooServiceTest.rejectsX'` |
| Один класс | `./mvnw -q test -Dtest=FooServiceTest -Dsurefire.failIfNoSpecifiedTests=false` | `./gradlew test --tests 'com.example.FooServiceTest'` |
| Интеграционный тест (Failsafe / отдельный source set) | `./mvnw -q verify -Dit.test=FooIT` (заодно прогонит unit-тесты модуля) | `./gradlew integrationTest --tests 'com.example.FooIT'` |
| Модуль в multi-module | добавь `-pl <module> -am` | `./gradlew :<module>:test ...` |
| Весь набор | `./mvnw verify` | `./gradlew check` |

Не меняй исходники, пока в той же рабочей копии идёт сборка.
