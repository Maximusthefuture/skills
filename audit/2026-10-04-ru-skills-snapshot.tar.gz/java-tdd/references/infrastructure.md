# Инфраструктура и уровень теста

**Открывай, когда:** пишешь первый интеграционный тест в задаче или не уверен, на каком уровне тестировать. Подробно — скилл `testing-with-discernment`; этот файл — минимум на случай, если его нет.

## Выбор инфраструктуры

Перед первым интеграционным тестом посмотри, что уже есть в сборке. Решает проект, а не привычка и не то, что сейчас запущено на машине. Подробно — `testing-with-discernment`.

```bash
grep -rnE 'org\.testcontainers|spring-boot-testcontainers|spring-kafka-test' \
  --include=pom.xml --include='*.gradle' --include='*.gradle.kts' --include='*.toml' \
  --exclude-dir=target --exclude-dir=build .
grep -rlE '@Testcontainers|@ServiceConnection|@EmbeddedKafka' \
  --include='*.java' --include='*.kt' --exclude-dir=target --exclude-dir=build .
```

| В сборке | БД | Kafka |
|---|---|---|
| Есть Testcontainers (любой артефакт `org.testcontainers` или `spring-boot-testcontainers`) | Testcontainers Postgres + `@ServiceConnection` | Testcontainers Kafka + `@ServiceConnection`; нет модуля `org.testcontainers:kafka` — добавь той же версии, что остальные |
| Нет Testcontainers | Тот же движок, что в проде, тем способом, каким проект уже поднимает его в тестах. Такого способа нет — спроси пользователя, прежде чем добавлять Testcontainers. Не H2 | `@EmbeddedKafka` из `spring-kafka-test` (test scope, версия из BOM Spring Boot; нет зависимости — добавь) |

- Смотри модуль, в котором пишешь тест, вместе с родительским pom / convention-плагином. Testcontainers в соседнем модуле тоже считается: подключи той же версии.
- Нет Docker — это не «нет Testcontainers». Проект на Testcontainers, а Docker недоступен — скажи пользователю; не переписывай тест на `@EmbeddedKafka` или H2 ради зелёного прогона.
- Есть базовый класс, `@TestConfiguration` с контейнерами или мета-аннотация с `@EmbeddedKafka` — пиши тест на них, а не заводи вторую настройку: это второй Spring-контекст и второй брокер.
- Существующие тесты с одного варианта на другой не переносишь в рамках чужой задачи.
- Добавленную тестовую зависимость назови в отчёте.

## Уровень теста — минимальная таблица

Подробно — `testing-with-discernment`. Если его нет:

| Поведение | Уровень |
|---|---|
| Бизнес-правило, расчёт, state machine, value object | JUnit 5 + AssertJ, без Spring |
| Запрос, маппинг, constraint, миграция | `@DataJpaTest` + `@AutoConfigureTestDatabase(replace = NONE)` + Testcontainers Postgres |
| HTTP-контракт: статус, тело, валидация, security | `@WebMvcTest` + `MockMvc`/`MockMvcTester` |
| Сценарий целиком: транзакции, outbox, listener'ы | `@SpringBootTest` + Testcontainers; Kafka без Testcontainers в проекте — `@EmbeddedKafka` |
| `@KafkaListener`, producer | `@SpringBootTest` + брокер по выбору инфраструктуры выше, `auto-offset-reset=earliest`, Awaitility на наблюдаемом результате (строка в БД, запись в исходящем топике или DLT) |
| Исходящий HTTP | WireMock на HTTP-границе |
| Асинхронность | Awaitility на наблюдаемом результате, не `Thread.sleep` |
| Время | инжектированный `Clock`, в тесте `Clock.fixed(...)` |
