---
name: "test-audit"
description: Invoke whenever writing, changing, reviewing, or sweeping tests in a Java / Spring Boot codebase (JUnit 5, Mockito, AssertJ, Spring test slices, Testcontainers). Authoring gate for new tests plus an audit workflow for low-value, implementation-coupled, or duplicative tests and the test-only production seams they demand. Use it even when the user just says "add a test", "fix this test", "clean up tests", "why is this test flaky", or asks to review a PR that touches src/test.
---

# Test Audit (Java / Spring Boot)

Three modes, one value bar.

- **Authoring mode** gates every new or changed test at write time.
- **Audit mode** runs focused sweeps for tests that re-assert source, duplicate
  stronger proof, couple behavior to implementation, or keep test-only
  production seams alive. Continue broad audits as separate coherent follow-up
  PRs; optimize for confidence, not deletion count.
- **Campaign mode** prunes one whole module's or bounded context's test surface
  (every test class a Maven/Gradle module or package tree owns). See
  [Campaign mode](#campaign-mode).

## Test boundaries in Spring Boot

Every contract has one primary owner at the strongest *cheap enough* boundary.
Know the layers before deciding where a test belongs:

| Boundary | Typical tooling | Owns |
| --- | --- | --- |
| Pure unit | JUnit 5 + AssertJ, no Spring context | domain logic, calculations, state machines, value objects |
| Unit with collaborators | JUnit 5 + Mockito (`@ExtendWith(MockitoExtension.class)`) | service orchestration where the collaborator is a real port/interface |
| Web slice | `@WebMvcTest` / `@WebFluxTest` + `MockMvc` / `WebTestClient` | HTTP contract: paths, status codes, validation, JSON shape, security rules on endpoints |
| Persistence slice | `@DataJpaTest` / `@DataJdbcTest` / `@DataMongoTest` (+ Testcontainers) | custom queries, mappings, constraints, migrations |
| Other slices | `@JsonTest`, `@RestClientTest`, `@JdbcTest` | serialization contracts, outbound HTTP client contracts |
| Integration | `@SpringBootTest` + Testcontainers (DB, Kafka, Redis…); Kafka on `@EmbeddedKafka` when the project has no Testcontainers | wiring, transactions, messaging, end-to-end flows |
| Architecture | ArchUnit | layering, dependency and naming rules |
| Consumer/provider contract | Spring Cloud Contract, Pact | cross-service API contracts |

A contract tested at a lower layer does not need a replay at every higher
layer, and vice versa. A second layer needs its own distinct risk (e.g.
transaction rollback, serialization, security filter chain, real SQL dialect)
that the owner cannot reach.

## Authoring gate

Before adding any test, answer four questions; a missing answer means do not
add it yet:

1. What observable behavior, invariant, or independent contract does it protect?
2. What credible regression makes it fail?
3. Why does existing coverage not already catch that failure? Prefer adding a
   case to an existing `@ParameterizedTest` (`@CsvSource`, `@MethodSource`) or
   shared fixture/builder over a near-duplicate test method; consolidate
   duplicated setup in the same change.
4. Does it need a production seam that no production caller needs — widened
   visibility (`public`/package-private just for tests), `@VisibleForTesting`,
   an extra constructor, a setter, a `@Profile("test")` bean in `src/main`, a
   property flag only tests set, a static reset hook? If yes, move the test to
   the real boundary instead.

Then check the test against every [junk pattern](#junk-patterns); a match fails
the gate unless the [retention bar](#retention-bar) names the contract it
independently guards. A test that would break under behavior-preserving
refactoring (renaming a private method, splitting a service, reordering
independent calls) is asserting implementation, not behavior; rewrite it at the
owning boundary before landing it.

Bug regression tests must fail on the pre-fix code for the intended reason and
pass after the owner-boundary fix. A regression test that never demonstrably
failed proves the mock, not the fix. One regression at the owner boundary
covers the bug; do not replay the same scenario in the controller, service,
and repository tests.

## Junk patterns

The shared checklist for both modes: the authoring gate rejects a new test that
matches one, and audits hunt for existing tests that do.

**Assertion and identity junk**
- assertion-free tests, or tests whose only assertion is `assertNotNull` /
  `assertDoesNotThrow` on something that cannot be null or throw;
- duplicate `contextLoads()` tests across modules or profiles that add nothing
  beyond the one smoke test (or beyond existing `@SpringBootTest` tests that
  already start the context);
- self-comparisons and identity copiers: `assertEquals(dto, dto)`, round-trip
  of a record through its own constructor, getter/setter tests, Lombok- or
  record-generated `equals`/`hashCode`/`toString` tests;
- tests of framework behavior: Spring Data derived query methods
  (`findByEmail`) without custom `@Query`, `@Value` injection, Jackson
  defaults, Bean Validation annotations that simply exist.

**Implementation coupling**
- `verify(mock).method(...)` / `ArgumentCaptor` call-shape tests where the call
  is not itself observable behavior (the effect is observable elsewhere);
- `verifyNoMoreInteractions` used as a blanket freeze of the implementation;
- `ReflectionTestUtils.setField/getField` or reflection on private members;
- private-method logic tested via widened visibility and duplicated by a test at
  the real public boundary;
- exact source, class-name, log-message, or SQL-string greps;
- copied fixtures, bean inventories, endpoint lists, enum value lists, or
  `application.yml` snapshots that just restate source.

**Mock junk**
- mocks that implement the asserted behavior:
  `when(repo.save(any())).thenReturn(entity)` then asserting the returned
  entity equals `entity`;
- `@MockitoBean`/`@MockBean` replacing the very bean whose behavior is asserted;
- one generic mock standing in for different APIs;
- `@WebMvcTest` tests that mock the service and only assert the controller
  delegated to it, with no HTTP contract (status, body, headers, validation)
  asserted;
- expected values produced by the code under test: expected JSON built by
  serializing the same DTO with the same `ObjectMapper`, expected mapping
  produced by calling the same MapStruct mapper.

**Fixture and environment lies**
- persistence asserted against H2 or an in-memory fake when production uses
  PostgreSQL/MySQL and the test depends on dialect behavior — use
  Testcontainers or drop the claim;
- Kafka consumption or publishing "covered" by a mocked `KafkaTemplate` or a
  direct call to the `@KafkaListener` method, when the test claims the
  listener, serialization, or DLT behavior — use the project's broker:
  Testcontainers Kafka if the build has Testcontainers, otherwise
  `@EmbeddedKafka`. `@EmbeddedKafka` itself is a real in-JVM broker, not a
  fake: do not flag existing tests for using it;
- fixtures that pre-seed the state, event, or callback ordering the owner
  should produce; persistence asserted via a repository the code path never
  writes to; `@Transactional` tests that assert data never actually flushed;
- `Thread.sleep`-timed async assertions instead of Awaitility or deterministic
  executors/`Clock` injection;
- feature-flag or `@ConditionalOnProperty` tests that restate the flag instead
  of exercising what the flag enables.

**Negative controls that lie**
- a 403 that comes from CSRF or a missing authentication, not from the
  authorization rule under test; a 400 from JSON parsing instead of the
  validation constraint being tested; an exception from a different guard than
  the one named;
- `@Disabled` tests kept "for later" with no ticket, and test names or
  `@DisplayName`s that promise more than the input exercises.

**Seam junk**
- tests whose only purpose is preserving test-only constructors, setters,
  static hooks, `@Profile("test")` beans, or public widening;
- dead production code whose only callers are tests;
- provider/module-local replays of shared library helpers already tested once.

## Value bar

Tests justify their maintenance cost (and their CI time — Spring contexts are
expensive) by protecting behavior, a credible regression, or an independently
meaningful contract. In an audit, an existing test that must change for
behavior-preserving refactoring is suspect, not automatically deletable; the
authoring gate still rejects new ones.

Before judging a candidate, read the complete test class, its base class and
`@TestConfiguration`s, the production owner, its entry point (controller,
listener, scheduler), callers, callees, sibling implementations, overlapping
tests, and relevant `git log`. Read root and module-level `AGENTS.md` /
`CLAUDE.md` / `CONTRIBUTING.md` first. When the test claims framework- or
library-backed behavior (Spring Security, Spring Data, Jackson, Hibernate),
check the dependency's actual behavior and version rather than assuming.

## Discovery

Keep discovery read-only and report evidence before editing. For broad scope,
run parallel discovery lanes when available:

- domain and service layer (`src/main/java/**/domain`, `**/service`);
- web layer (controllers, `@ControllerAdvice`, security config, DTOs);
- persistence and messaging (repositories, entities, migrations, Kafka/Rabbit
  listeners and producers);
- configuration, build, and test infrastructure (`@TestConfiguration`, base
  test classes, `src/test/resources`, `pom.xml` / `build.gradle`);
- a cross-cutting pattern sweep.

Useful sweep greps (a hit is a lead, not a verdict):

```bash
rg -n 'verify\(|verifyNoMoreInteractions|ArgumentCaptor' src/test
rg -n 'ReflectionTestUtils|setAccessible\(true\)|@VisibleForTesting' src
rg -n 'void contextLoads|@Disabled|Thread\.sleep' src/test
rg -n '@MockBean|@MockitoBean|@SpyBean|@MockitoSpyBean' src/test
rg -n '@Profile\("test"\)|@ConditionalOnProperty' src/main
rg -n 'jdbc:h2|@AutoConfigureTestDatabase' src/test
```

Outside campaign mode, prefer a few high-confidence candidates over a large
speculative inventory.

## Retention bar

Keep a test when it independently enforces a public REST/gRPC API, OpenAPI
spec, JSON/Avro/Protobuf serialization, message or event schema,
`@ConfigurationProperties` binding and defaults, database migration
(Flyway/Liquibase), custom query, transaction boundary, security rule,
idempotency, retry/backoff, time-zone or locale behavior, ArchUnit rule,
consumer/provider contract, or published library API. Also keep:

- interaction verification when the interaction *is* the observable behavior
  (an email sent, an event published to Kafka, an external API called exactly
  once, an audit record written) and no cheaper observable proof exists;
- call ordering when order is observable behavior;
- regressions with a credible failure mode;
- source inspection (e.g. ArchUnit, a property-key check) when it is the
  cheapest independent guard: it fails when the contract changes (the
  user-facing key, path, or header) and survives an identifier-only refactor;
- a retained test that fails on the baseline: treat it as a possible product
  bug, reproduce it, and repair the owner rather than deleting it.

Static or slow is not a deletion reason. A test that resembles implementation
may still be the independent contract; prove otherwise before removing it.
Optional stronger evidence: run PIT mutation testing on the owner class to see
whether the candidate kills any mutant no other test kills.

## Candidate evidence

Record every field below before editing. A missing field means the candidate is
not ready for deletion:

- exact test class, method, and module;
- what failure it can actually detect;
- non-test callers of the covered production or support seam;
- stronger remaining owner-boundary proof, or why no proof is needed;
- relevant history (`git log -L` / blame) and the reason the test or seam
  exists;
- production or test-support deletion unlocked (seams, `@TestConfiguration`s,
  builders, test profiles);
- risk and the focused validation command.

## Edit shape

Choose one coherent owner-boundary batch (one module, one bounded context, or
one layer). Delete obsolete test-only constructors, setters, visibility
widening, `@VisibleForTesting` members, test profiles, and dead production
paths instead of preserving aliases. Move retained regressions to their
canonical owners. Consolidate repeated per-endpoint or per-entity assertions
into one parameterized contract test.

Prefer net-negative production LOC. Do not add replacement tests that restate
the same implementation, and do not convert uncertain candidates into cleanup
to increase deletion counts. Reducing the number of distinct Spring contexts
(fewer unique `@MockitoBean` combinations, fewer `@DirtiesContext`) is a valid
secondary win — note it in the handoff.

## Validation

Never edit sources or tests while a build or test run is in progress in the
same checkout. Use the project wrapper (`./mvnw` or `./gradlew`), not a global
install.

1. Run the smallest owner and sibling tests:
   - Maven: `./mvnw -pl <module> -am test -Dtest='FooServiceTest,FooControllerTest' -Dsurefire.failIfNoSpecifiedTests=false`
   - Gradle: `./gradlew :<module>:test --tests 'com.example.foo.*'`
   - Integration tests (Failsafe / separate source set): `./mvnw -pl <module> verify -Dit.test=FooIT` or `./gradlew :<module>:integrationTest`
2. For a removed regression test, prove the remaining owner test fails on the
   pre-fix behavior (temporarily revert the fix or mutate the owner) and passes
   after.
3. Run formatting and static checks the project uses (Spotless, Checkstyle,
   PMD, SpotBugs, Error Prone), then `git diff --check`.
4. Run the full module build (`./mvnw -pl <module> -am verify` /
   `./gradlew :<module>:check`) and then whatever gate repository policy
   requires for the changed paths.
5. Inspect `git diff --numstat`; report `src/main` separately from `src/test`
   and test support.
6. After final audit edits, do a self-review of the full diff before handing
   off.

## Landing and continuation

Commit, push, open a PR, or merge only when authorized. Follow the
repository's contribution and PR conventions. Land one coherent PR at a time;
after landing, refresh from the current main branch and rerun read-only
discovery for the next high-confidence batch.

## Campaign mode

For a whole-module prune: inventory every test class in the module with its
boundary (unit/slice/integration), the contract it claims, and its owner; map
each contract to exactly one primary owner; then run audit mode over the
inventory in batches, one PR per batch. Track retained false positives so later
passes do not re-litigate them.

## Handoff

Report:

- root cause and removed low-value categories;
- production owner simplifications (seams, visibility, test profiles removed);
- retained false positives and why they remain valuable;
- focused and full proof actually run (exact commands);
- production versus test LOC;
- change in test run time or number of Spring contexts, if measured;
- PR and merge state;
- named follow-ups.
