# orders-service

Тестовый Spring Boot проект для проверки скиллов и агентов из `.claude/`.

## Стек и команды

Java 21, Spring Boot 3.1.5, Maven через wrapper, Testcontainers PostgreSQL (нужен запущенный Docker).

- тесты: `./mvnw test`
- полный прогон: `./mvnw verify`
- один тест: `./mvnw -q test -Dtest='FooTest#method' -Dsurefire.failIfNoSpecifiedTests=false`
- запуск: `./mvnw spring-boot:run`

## Процесс разработки

Любую задачу по коду (фича, баг, рефакторинг) начинай со скилла `java-dev-flow`.
Тесты пишутся первыми (`java-tdd`). Для задач M и L проверка — агенты `java-code-reviewer` и `critic` по diff, одним сообщением.
Ревью diff — скилл `java-code-review` или агент `java-code-reviewer`, не встроенный `/code-review`.
